# Aaron Perkins
# 09/23/2026
# P3LAB
# Branching to determine which coins are needed

user_money = float(input("Enter the amount of money as a float: $"))

money = int(user_money * 100)

print()

######################### DOLLARS ####################################
dollars = money//100
money = money - dollars * 100
print("Dollars:", dollars)
print("Money Remaining:", money)

######################### Quarters ####################################
quarters = money//25
money = money - quarters * 25
print("Quarters:", quarters)
print("Money Remaining:", money)

######################### DIMES ####################################
dimes = money//10

money = money - dimes * 10

print("Dimes:", dimes)
print("Money Remaining:", money)

######################### Nickels ####################################
nickles = money//5

money = money - nickles * 5

print("Nickles:", nickles)
print("Money Remaining:", money)

pennies = money
print("Pennies", pennies)

if dollars == 1:
    print(dollars, "Dollar")
if dollars > 1:
    print(dollars, "Dollars")