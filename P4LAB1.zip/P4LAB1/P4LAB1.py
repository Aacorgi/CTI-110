# Aaron Perkins
# 9/28/2026
# P4LAB1
# use a for loop and while to draw a house

import turtle

# make new window to display the output
window = turtle.Screen()

# create yhe turtle object that draws
joe = turtle.Turtle()

for side in range(4):
    joe.forward(100)
    joe.right(90)

num = 0
while num < 3:
    joe.forward(100)
    joe.left(120)
    num += 1

input()