# Aaron Perkins
# 09/14/2026
# P2LAB1
# Calculate the area of a circle

import math

radius = float(input("What is the radius of the circle? "))
print()

diameter = 2 * radius
print("The diameter is ", diameter)
print()

circ = diameter * 3.14
print("The circumference of the circle is ", circ)
print()

area = 3.14 * radius * radius
print("The area of the circle is ", area)