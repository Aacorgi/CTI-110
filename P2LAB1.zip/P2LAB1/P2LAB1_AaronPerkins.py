# Aaron Perkins
# 09/14/2026
# P2LAB1
# Calculate the area of a circle

import math
print(math.pi)

radius = float(input("What is the radius of the circle? "))
print()

diameter = 2 * radius
print(f"The diameter is {diameter:.1f}")
print()

circ = 2 * math.pi * radius
print(f"The circumference of the circle is {circ:.2f} ")
print()

area = math.pi  * radius**2
print(f"The area of the circle is {area:.3f}")