#Aaron Perkins
#09/21/2026
#P3
#

name = input("Enter employees name: ")
hours = float(input("Enter hours worked this week: "))
rate = float(input("Enter employees pay rate: "))


if hours > 40:
    # calculate overtime
    overtime_hours = hours - 40
    # calculate over pay
    overtime_pay = overtime_hours * (rate * 1.5)\
    # calculate salary for regular hours
    regular_pay = 40 * rate
    # calculate gross pay
else:
    overtime_pay = 0
    overtime_hours = 0
    gross_pay = hours * rate

# Display results

print("-----------------------------------")
print("Employee name:   ",name)
print(f'{"Hours worked":<15}{"Pay Rate":<12}{"OverTime Pay":<12}{"Regular hours":<15}{"Gross Pay":<12}')
print("----------------------------------------------")
print(f'{}')