# Aaron Perkins
# 09/02/26
# P1LAB1
# working with python

first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

print("Hello,",first_name, last_name +"!","Welcome to CTI-110")