# Aaron Perkins
# 9/28/2026
# P4LAB2
# loops


# Create a variable to control the main loop
run_again = "yes"

while run_again == "yes":
    print()
    # Logic starts here
    # Get integer from the user
    user_num = int(input("Enter an integer: "))
    if user_num < 0:
        print("No negative numbers allowed!!")
    else:
        # This means the integer is negative
        for multi in range(1,13):
            print(f"{user_num} * {multi} = {user_num * multi}")
    
    
    print()
    run_again = input("Would you like to run the program again? ")
    
print()
print("Program has ended")