# Aaron Perkins
# 09/09/2026
# P1HW2
# Calculate travel expenses

print("This program calculates and displays travel expenses")

budget = int(input("Enter Budget: "))
destination = (input("Enter your travel destination: "))
gas = int(input("How much do you think you will spend on gas? "))
hotel = int(input("Approximately, how much will you need for accomodation/hotel? "))
food = int(input("Last, how much do you need for food? "))
print()

print("-------Travel Expenses-------")
print("Location: ", destination)
print("Initial Budget: ", budget)
print()

print("Fuel: ", gas)
print("Accomodation: ", hotel)
print("Food: ", food)
print()

sum_result = budget - gas - hotel - food

print("Remaining Balance", sum_result)
